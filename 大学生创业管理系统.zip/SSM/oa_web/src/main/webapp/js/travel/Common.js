
document.write('<script type=\"text/javascript\" src=\"js/jquery-1.8.2.min.js\"></script>');
document.write('<script type=\"text/javascript\" src=\"js/jquery-ui-1.8.24.custom.min.js\"></script>');
document.write(' <script type="text/javascript" src="js/jquery.mobile.customized.min.js"></script>');
document.write('    <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>');
document.write('        <script type="text/javascript" src="js/camera.min.js"></script>');
document.write('        <script type="text/javascript" src="js/jquery.isotope.min.js"></script>');
document.write('            <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>');
document.write('               <script type="text/javascript" src="js/selectnav.min.js"></script>');
document.write('                   <script type="text/javascript" src="http://maps.google.com/maps?file=api&amp;v=2&amp;sensor=false&amp;key=AIzaSyB3tShW1hLlV2lYW8_sCVln6TLF2bWvgU8"></script>');
  document.write('               <script type="text/javascript" src="js/jquery.googlemaps.1.01.min.js"></script>');  
    document.write('                <script type="text/javascript" src="js/theme.js"></script>');