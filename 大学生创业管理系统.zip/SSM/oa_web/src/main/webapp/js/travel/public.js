$(function(){
    $(".navigation").load("http://127.0.0.1:8848/11/navigation.html");
    $(".footer").load("http://127.0.0.1:8848/11/footer.html");
});